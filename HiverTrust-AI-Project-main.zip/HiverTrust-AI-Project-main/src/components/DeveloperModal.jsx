import React from 'react';
import { X, User, MapPin, Phone, Mail, CheckCircle2 } from 'lucide-react';
import { DEVELOPER_DETAILS } from '../data/goldenDataset';

export default function DeveloperModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative space-y-6 animate-in fade-in zoom-in duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-4 border-b border-slate-200 pb-5">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white text-xl font-bold shadow-md">
            MV
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-bold text-slate-900">{DEVELOPER_DETAILS.name}</h3>
              <span className="bg-sky-100 text-sky-800 text-xs px-2 py-0.5 rounded font-mono font-semibold border border-sky-300">
                SDE Intern Candidate
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Hiver Take-Home Assignment Submission</p>
          </div>
        </div>

        {/* Developer Contact Details List */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3.5 text-sm">
          <div className="flex items-center gap-3 text-slate-800">
            <div className="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center">
              <User className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] text-slate-500 block uppercase font-mono">Full Name</span>
              <span className="font-bold text-slate-900">{DEVELOPER_DETAILS.name}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 text-slate-800">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] text-slate-500 block uppercase font-mono">Location</span>
              <span className="font-bold text-slate-900">{DEVELOPER_DETAILS.location}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 text-slate-800">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <Phone className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] text-slate-500 block uppercase font-mono">Phone Number</span>
              <a href={`tel:${DEVELOPER_DETAILS.phone}`} className="font-bold text-emerald-800 hover:underline">
                {DEVELOPER_DETAILS.phone}
              </a>
            </div>
          </div>

          <div className="flex items-center gap-3 text-slate-800">
            <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center">
              <Mail className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] text-slate-500 block uppercase font-mono">Email Address</span>
              <a href={`mailto:${DEVELOPER_DETAILS.email}`} className="font-bold text-amber-900 hover:underline">
                {DEVELOPER_DETAILS.email}
              </a>
            </div>
          </div>
        </div>

        {/* Project Compliance Badges */}
        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2 text-xs">
          <span className="text-slate-800 font-bold flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Assignment Checklist Verification:
          </span>
          <div className="grid grid-cols-2 gap-1.5 text-[11px] text-slate-600 font-mono">
            <span>✓ Runnable Pipeline</span>
            <span>✓ 200 Golden Set</span>
            <span>✓ LLM-as-Judge Suite</span>
            <span>✓ Physical Diagrams</span>
            <span>✓ 14 Decision Logs</span>
            <span>✓ 5 Failure Modes</span>
          </div>
        </div>

        {/* Close CTA */}
        <button
          onClick={onClose}
          className="w-full bg-sky-600 hover:bg-sky-500 text-white font-semibold py-2.5 rounded-xl text-xs transition shadow-md"
        >
          Close Developer Details
        </button>
      </div>
    </div>
  );
}
