import React, { useState } from 'react';
import { Database, Search, Filter, ShieldAlert, CheckCircle2, Star, Bot } from 'lucide-react';
import { GOLDEN_DATASET } from '../data/goldenDataset';

export default function GoldenDatasetExplorer() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrandFilter, setSelectedBrandFilter] = useState('ALL');
  const [selectedEscalateFilter, setSelectedEscalateFilter] = useState('ALL');

  const filteredData = GOLDEN_DATASET.filter(item => {
    const matchesSearch = item.tweet.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.intent.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          item.author.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesBrand = selectedBrandFilter === 'ALL' || item.brand === selectedBrandFilter;
    const matchesEscalate = selectedEscalateFilter === 'ALL' || 
                            (selectedEscalateFilter === 'ESCALATE' && item.escalate) ||
                            (selectedEscalateFilter === 'AUTO' && !item.escalate);
    
    return matchesSearch && matchesBrand && matchesEscalate;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 bg-white">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2 text-emerald-600 font-mono text-xs uppercase tracking-wider font-semibold mb-1">
          <Database className="w-4 h-4" /> Dataset Repository
        </div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Golden Evaluation Set Explorer (N=200)</h2>
        <p className="text-slate-600 text-sm mt-1">
          Hand-labelled, stratified dataset created from Twitter customer support threads. Each sample includes human annotations, intent tags, ground truth resolutions, and judge quality ratings.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col md:flex-row gap-4 justify-between items-center">
        {/* Search */}
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search tweets, intent tags, authors..."
            className="w-full bg-white border border-slate-300 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-sky-500"
          />
        </div>

        {/* Dropdown Filters */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto text-xs">
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-600 font-medium">Brand:</span>
            <select
              value={selectedBrandFilter}
              onChange={(e) => setSelectedBrandFilter(e.target.value)}
              className="bg-white border border-slate-300 text-slate-800 font-medium rounded-md px-2.5 py-1.5 focus:outline-none focus:border-sky-500"
            >
              <option value="ALL">All Brands (4)</option>
              <option value="@AppleSupport">@AppleSupport</option>
              <option value="@AmazonHelp">@AmazonHelp</option>
              <option value="@SpotifyCares">@SpotifyCares</option>
              <option value="@Uber_Support">@Uber_Support</option>
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-600 font-medium">Escalation:</span>
            <select
              value={selectedEscalateFilter}
              onChange={(e) => setSelectedEscalateFilter(e.target.value)}
              className="bg-white border border-slate-300 text-slate-800 font-medium rounded-md px-2.5 py-1.5 focus:outline-none focus:border-sky-500"
            >
              <option value="ALL">All Handling Types</option>
              <option value="AUTO">Auto-Handled</option>
              <option value="ESCALATE">Human Escalation</option>
            </select>
          </div>
        </div>
      </div>

      {/* Dataset Records Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredData.map(item => (
          <div key={item.id} className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-sm flex flex-col justify-between space-y-4 hover:border-slate-300 transition">
            {/* Header / ID / Brand */}
            <div>
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-slate-500 font-bold">{item.id}</span>
                  <span className="text-xs font-semibold text-sky-700">{item.brand}</span>
                  <span className="text-xs text-slate-500">by {item.author}</span>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-bold flex items-center gap-1 ${
                  item.escalate
                    ? 'bg-amber-100 text-amber-900 border border-amber-300'
                    : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                }`}>
                  {item.escalate ? <ShieldAlert className="w-3 h-3 text-amber-700" /> : <CheckCircle2 className="w-3 h-3 text-emerald-700" />}
                  {item.escalate ? 'Human Escalation' : 'Auto-Handled'}
                </span>
              </div>

              {/* Customer Tweet */}
              <div className="bg-white p-3 rounded-lg border border-slate-200 mb-3 shadow-xs">
                <span className="text-[10px] uppercase font-mono text-slate-500 block mb-1">Incoming Customer Tweet:</span>
                <p className="text-xs text-slate-900 font-sans leading-relaxed">"{item.tweet}"</p>
              </div>

              {/* Intent & Ground Truth Reply */}
              <div className="space-y-2 text-xs">
                <div>
                  <span className="text-slate-500 text-[11px] block">Annotated Intent:</span>
                  <span className="text-sky-800 font-bold">{item.intent}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[11px] block">Ground Truth Resolution Reply:</span>
                  <p className="text-slate-800 bg-white p-2.5 rounded border border-slate-200 text-[11px] font-sans">
                    "{item.ground_truth_reply}"
                  </p>
                </div>
              </div>
            </div>

            {/* Footer Scores */}
            <div className="pt-3 border-t border-slate-200 flex justify-between items-center text-xs">
              <div className="flex items-center gap-1 text-amber-700 font-mono font-semibold">
                <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" /> Human Rating: {item.human_score}/5.0
              </div>
              <div className="flex items-center gap-1 text-indigo-700 font-mono font-semibold">
                <Bot className="w-3.5 h-3.5" /> Judge Rating: {item.judge_grounding_score}/5.0
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
