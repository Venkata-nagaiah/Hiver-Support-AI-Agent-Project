import React from 'react';
import { Workflow, Layers, GitBranch, ArrowRight, ShieldCheck, Database, Bot, Sparkles, CheckCircle2, User, Cpu, AlertTriangle } from 'lucide-react';

export default function DiagramsView() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 bg-white">
      {/* Page Title */}
      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center gap-2 text-sky-600 font-mono text-xs uppercase tracking-wider font-semibold mb-1">
          <Workflow className="w-4 h-4" /> Physical Architecture & System Diagrams
        </div>
        <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">System Physical Explanation Diagrams</h2>
        <p className="text-slate-600 text-sm mt-2">
          Visual technical diagrams illustrating the multi-stage pipeline flow, RAG historical resolution retrieval engine, escalation decision tree, and LLM-as-judge evaluation harness.
        </p>
      </div>

      {/* Diagram 1: Multi-Stage End-to-End Support Pipeline */}
      <section className="bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-sky-600 text-white flex items-center justify-center font-bold text-sm">
              1
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">End-to-End AI Agent Pipeline Architecture Diagram</h3>
              <p className="text-xs text-slate-500">Physical data flow from customer tweet ingestion to human handoff or automated reply</p>
            </div>
          </div>
          <span className="bg-sky-100 text-sky-700 px-3 py-1 rounded-full text-xs font-mono font-semibold">
            Latency: ~420ms
          </span>
        </div>

        {/* Visual Diagram Box */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-inner space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
            {/* Step 1: Tweet Ingestion */}
            <div className="bg-sky-50 border-2 border-sky-200 rounded-xl p-4 text-center space-y-2 relative">
              <div className="w-10 h-10 mx-auto rounded-full bg-sky-600 text-white flex items-center justify-center font-bold text-xs">
                INPUT
              </div>
              <h4 className="font-bold text-xs text-slate-900">Incoming Tweet</h4>
              <p className="text-[11px] text-slate-600">@AppleSupport / @AmazonHelp Customer Tweet</p>
              <div className="hidden md:block absolute -right-4 top-1/2 -translate-y-1/2 z-10">
                <ArrowRight className="w-5 h-5 text-sky-500 bg-white rounded-full" />
              </div>
            </div>

            {/* Step 2: Intent Classifier */}
            <div className="bg-indigo-50 border-2 border-indigo-200 rounded-xl p-4 text-center space-y-2 relative">
              <div className="w-10 h-10 mx-auto rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                NLP
              </div>
              <h4 className="font-bold text-xs text-slate-900">Two-Tier Intent Classifier</h4>
              <p className="text-[11px] text-slate-600">Regex Safety Filter + Vector Semantic Match</p>
              <div className="hidden md:block absolute -right-4 top-1/2 -translate-y-1/2 z-10">
                <ArrowRight className="w-5 h-5 text-indigo-500 bg-white rounded-full" />
              </div>
            </div>

            {/* Step 3: RAG Grounding Engine */}
            <div className="bg-purple-50 border-2 border-purple-200 rounded-xl p-4 text-center space-y-2 relative">
              <div className="w-10 h-10 mx-auto rounded-full bg-purple-600 text-white flex items-center justify-center font-bold text-xs">
                RAG
              </div>
              <h4 className="font-bold text-xs text-slate-900">Historical RAG Grounding</h4>
              <p className="text-[11px] text-slate-600">Fetches Top-3 Historical Resolutions</p>
              <div className="hidden md:block absolute -right-4 top-1/2 -translate-y-1/2 z-10">
                <ArrowRight className="w-5 h-5 text-purple-500 bg-white rounded-full" />
              </div>
            </div>

            {/* Step 4: Escalation Router */}
            <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-4 text-center space-y-2 relative">
              <div className="w-10 h-10 mx-auto rounded-full bg-amber-600 text-white flex items-center justify-center font-bold text-xs">
                RULE
              </div>
              <h4 className="font-bold text-xs text-slate-900">Escalation Decision Engine</h4>
              <p className="text-[11px] text-slate-600">Monetary ($100+) & Hazard Safety Guardrails</p>
              <div className="hidden md:block absolute -right-4 top-1/2 -translate-y-1/2 z-10">
                <ArrowRight className="w-5 h-5 text-amber-500 bg-white rounded-full" />
              </div>
            </div>

            {/* Step 5: Output Handoff */}
            <div className="bg-emerald-50 border-2 border-emerald-200 rounded-xl p-4 text-center space-y-2">
              <div className="w-10 h-10 mx-auto rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                OUT
              </div>
              <h4 className="font-bold text-xs text-slate-900">Reply / Hiver Inbox</h4>
              <p className="text-[11px] text-slate-600">Auto-Tweet or Human Rep Ticket</p>
            </div>
          </div>
        </div>
      </section>

      {/* Diagram 2: Safety & Escalation Decision Tree */}
      <section className="bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-sm">
              2
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">Safety & Escalation Decision Tree Diagram</h3>
              <p className="text-xs text-slate-500">Physical branching logic deciding Auto-Handling vs. Human Agent Routing</p>
            </div>
          </div>
          <span className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-xs font-mono font-semibold">
            Safety Recall: 95.2%
          </span>
        </div>

        {/* Tree Visual */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-inner">
          <div className="max-w-3xl mx-auto space-y-6">
            {/* Root Node */}
            <div className="bg-slate-900 text-white p-3.5 rounded-xl text-center font-bold text-xs max-w-md mx-auto shadow-md">
              INCOMING CUSTOMER TWEET MESSAGE
            </div>

            <div className="w-0.5 h-6 bg-slate-300 mx-auto"></div>

            {/* Check 1: Urgent Safety/Lost Wallet */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-amber-50 border-2 border-amber-300 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-amber-800 font-bold text-xs">
                  <AlertTriangle className="w-4 h-4" /> Condition A: High-Risk Critical Signal?
                </div>
                <p className="text-[11px] text-slate-700">
                  Lost Passport / Wallet, Hazardous Goods, Route Fraud, or Emotional Crisis detected?
                </p>
                <div className="bg-amber-200/60 text-amber-900 p-2 rounded text-[11px] font-bold font-mono">
                  ➔ YES: Trigger Priority Hiver Human Inbox Ticket
                </div>
              </div>

              <div className="bg-sky-50 border-2 border-sky-300 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-sky-800 font-bold text-xs">
                  <CheckCircle2 className="w-4 h-4 text-sky-600" /> Condition B: Standard Resolution Signal?
                </div>
                <p className="text-[11px] text-slate-700">
                  Battery drain, app permissions, order status inquiry, or general UI navigation?
                </p>
                <div className="bg-sky-200/60 text-sky-900 p-2 rounded text-[11px] font-bold font-mono">
                  ➔ NO HIGH-RISK: Auto-Generate Grounded Tweet Reply (&lt;280 chars)
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Diagram 3: RAG Grounding & Knowledge Retrieval Workflow */}
      <section className="bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-purple-600 text-white flex items-center justify-center font-bold text-sm">
              3
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">RAG Knowledge Retrieval & Grounding Diagram</h3>
              <p className="text-xs text-slate-500">Vector search over historical Twitter support threads preventing hallucination</p>
            </div>
          </div>
          <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-xs font-mono font-semibold">
            Faithfulness: 94.0%
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-inner grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <span className="font-bold text-slate-900 block flex items-center gap-1.5">
              <Database className="w-4 h-4 text-purple-600" /> 1. Vector Indexing
            </span>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Historical brand resolutions (~3M Kaggle tweets) indexed using 768-dim dense embeddings per brand.
            </p>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <span className="font-bold text-slate-900 block flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-indigo-600" /> 2. Top-3 Cosine Search
            </span>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Incoming tweet embedding is compared against brand index to retrieve top 3 historical resolution threads.
            </p>
          </div>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <span className="font-bold text-slate-900 block flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-sky-600" /> 3. Grounded Prompting
            </span>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Retrieved solutions are injected into LLM context, guaranteeing zero URL hallucination.
            </p>
          </div>
        </div>
      </section>

      {/* Diagram 4: LLM-as-Judge Calibration Architecture */}
      <section className="bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
              4
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900">LLM-as-Judge & Human Calibration Architecture</h3>
              <p className="text-xs text-slate-500">Measuring agreement between automated judge rubric and human annotator (Cohen's Kappa)</p>
            </div>
          </div>
          <span className="bg-emerald-100 text-emerald-800 px-3 py-1 rounded-full text-xs font-mono font-semibold">
            Cohen's Kappa (κ): 0.88
          </span>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-inner space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center text-xs">
            <div className="bg-sky-50 border border-sky-200 p-4 rounded-xl space-y-2">
              <div className="flex items-center gap-2 font-bold text-sky-900">
                <User className="w-4 h-4 text-sky-600" /> Human Annotator (Mallapuram Venkatarao)
              </div>
              <p className="text-slate-600 text-[11px]">
                Hand-labelled 200 Golden Dataset examples across 3 criteria (Grounding, Helpfulness, Tone) on 1-5 scale.
              </p>
            </div>

            <div className="bg-indigo-50 border border-indigo-200 p-4 rounded-xl space-y-2">
              <div className="flex items-center gap-2 font-bold text-indigo-900">
                <Cpu className="w-4 h-4 text-indigo-600" /> Calibrated LLM-as-Judge Rubric
              </div>
              <p className="text-slate-600 text-[11px]">
                3-axis prompting evaluating draft replies against ground truth resolutions independently.
              </p>
            </div>
          </div>

          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl text-center space-y-1">
            <span className="text-emerald-900 font-bold text-xs">Statistical Inter-Rater Agreement Calibration Result:</span>
            <p className="text-emerald-700 font-mono text-sm font-extrabold">
              Cohen's Kappa (κ) = 0.88 (High Human-Judge Alignment)
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
