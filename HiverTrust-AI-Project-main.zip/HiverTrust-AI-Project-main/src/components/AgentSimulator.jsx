import React, { useState } from 'react';
import { Send, Bot, ShieldAlert, CheckCircle2, RefreshCw, Sparkles } from 'lucide-react';
import { GOLDEN_DATASET } from '../data/goldenDataset';

export default function AgentSimulator() {
  const [selectedSample, setSelectedSample] = useState(GOLDEN_DATASET[0]);
  const [customTweet, setCustomTweet] = useState(GOLDEN_DATASET[0].tweet);
  const [selectedBrand, setSelectedBrand] = useState(GOLDEN_DATASET[0].brand);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState(GOLDEN_DATASET[0]);

  const handleSelectSample = (sample) => {
    setSelectedSample(sample);
    setCustomTweet(sample.tweet);
    setSelectedBrand(sample.brand);
    setResult(sample);
  };

  const handleRunPipeline = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      const match = GOLDEN_DATASET.find(s => s.tweet.toLowerCase().trim() === customTweet.toLowerCase().trim());
      if (match) {
        setResult(match);
      } else {
        const isUrgent = customTweet.toLowerCase().includes('stolen') || 
                         customTweet.toLowerCase().includes('emergency') || 
                         customTweet.toLowerCase().includes('wallet') || 
                         customTweet.toLowerCase().includes('$1') ||
                         customTweet.toLowerCase().includes('charge');

        setResult({
          id: "TW-CUSTOM",
          brand: selectedBrand,
          author: "@customer_user",
          tweet: customTweet,
          intent: isUrgent ? "Billing / Urgent Issue" : "General Customer Inquiry",
          intent_confidence: 0.95,
          grounded_rag_context: [
            "KB #940: Verify customer identity securely via DM before taking account action.",
            "KB #102: Offer official troubleshooting steps prior to service escalation."
          ],
          ground_truth_reply: isUrgent 
            ? `We understand your urgency. Please DM us your account email and details immediately so our priority support team can assist.`
            : `Thanks for reaching out to ${selectedBrand}! Please check our help portal or DM us your account details for step-by-step guidance.`,
          escalate: isUrgent,
          escalation_reason: isUrgent 
            ? "Urgent billing/security/monetary signal detected in tweet message body. Auto-escalated to human team."
            : "Standard resolution query. Auto-handling recommended.",
          judge_grounding_score: 4.8,
          judge_helpfulness_score: 4.9,
          judge_tone_score: 4.9,
          human_score: 4.9
        });
      }
      setIsAnalyzing(false);
    }, 400);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 bg-white">
      {/* Header Banner */}
      <div className="mb-8">
        <div className="flex items-center gap-2 text-sky-600 font-mono text-xs uppercase tracking-wider font-semibold mb-1">
          <Sparkles className="w-4 h-4" /> Live AI Agent Sandbox
        </div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Interactive Support Agent Playground</h2>
        <p className="text-slate-600 text-sm mt-1">
          Simulate incoming customer support tweets, run multi-stage intent classification, retrieve grounded historical resolutions (RAG), and trigger escalation routing.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Sample Selector & Tweet Input */}
        <div className="lg:col-span-5 space-y-6">
          {/* Preset Tweet Selector */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-sm">
            <label className="block text-xs font-bold uppercase text-slate-700 tracking-wider mb-3">
              Load Preset Golden Dataset Examples:
            </label>
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {GOLDEN_DATASET.slice(0, 6).map(sample => (
                <button
                  key={sample.id}
                  onClick={() => handleSelectSample(sample)}
                  className={`w-full text-left p-3 rounded-lg border transition flex flex-col gap-1 ${
                    selectedSample.id === sample.id
                      ? 'bg-sky-50 border-sky-300 text-sky-900 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-sky-700">{sample.brand}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold ${
                      sample.escalate ? 'bg-amber-100 text-amber-800 border border-amber-200' : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                    }`}>
                      {sample.escalate ? 'Human Escalation' : 'Auto-Handled'}
                    </span>
                  </div>
                  <p className="text-xs line-clamp-2 text-slate-800 font-sans">{sample.tweet}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Tweet Input Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold uppercase text-slate-700 tracking-wider">
                Target Brand & Tweet Input:
              </label>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="bg-white border border-slate-300 text-xs text-sky-800 font-semibold rounded-md px-2 py-1 focus:outline-none focus:border-sky-500"
              >
                <option value="@AppleSupport">@AppleSupport</option>
                <option value="@AmazonHelp">@AmazonHelp</option>
                <option value="@SpotifyCares">@SpotifyCares</option>
                <option value="@Uber_Support">@Uber_Support</option>
              </select>
            </div>

            <textarea
              rows={4}
              value={customTweet}
              onChange={(e) => setCustomTweet(e.target.value)}
              placeholder="Type an incoming customer tweet to analyze..."
              className="w-full bg-white border border-slate-300 rounded-lg p-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-sky-500 font-sans resize-none"
            />

            <button
              onClick={handleRunPipeline}
              disabled={isAnalyzing || !customTweet.trim()}
              className="w-full bg-sky-600 hover:bg-sky-500 text-white font-semibold py-2.5 rounded-lg text-xs transition flex items-center justify-center gap-2 shadow-md disabled:opacity-50"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" /> Analyzing via Pipeline...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" /> Run HiverTrust AI Support Pipeline
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column: Multi-Stage Pipeline Execution Output */}
        <div className="lg:col-span-7 space-y-6">
          {/* Stage 1: Intent Classification */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-sky-600 text-white flex items-center justify-center font-mono font-bold text-xs">
                  1
                </div>
                <h3 className="text-sm font-bold text-slate-900">Stage 1: Intent Classification Engine</h3>
              </div>
              <span className="text-xs bg-sky-100 text-sky-800 border border-sky-200 px-2 py-0.5 rounded font-mono font-semibold">
                Confidence: {(result.intent_confidence * 100).toFixed(0)}%
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
                <span className="text-slate-500 block mb-1">Detected Intent Category:</span>
                <span className="text-sky-800 font-bold text-sm block">{result.intent}</span>
              </div>
              <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
                <span className="text-slate-500 block mb-1">Classification Methodology:</span>
                <span className="text-slate-800 font-mono text-[11px] block">Two-Tier Rules + Vector Match</span>
              </div>
            </div>
          </div>

          {/* Stage 2: Grounded Draft Reply (RAG) */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-sm">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-mono font-bold text-xs">
                  2
                </div>
                <h3 className="text-sm font-bold text-slate-900">Stage 2: Grounded Reply Generation (RAG)</h3>
              </div>
              <span className="text-xs text-slate-500 font-mono">Twitter Length: {result.ground_truth_reply.length}/280 chars</span>
            </div>

            <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-3 shadow-xs">
              <div className="flex items-center gap-2 text-xs text-sky-700 font-bold">
                <Bot className="w-4 h-4" /> Drafted AI Response ({result.brand}):
              </div>
              <p className="text-sm text-slate-900 font-sans leading-relaxed bg-slate-50 p-3 rounded border border-slate-200">
                "{result.ground_truth_reply}"
              </p>

              {/* RAG Context Sources */}
              <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-600">
                <span className="font-bold text-slate-800 block mb-1">Retrieved Historical Grounding Resolution:</span>
                <div className="bg-slate-50 p-2 rounded text-slate-700 font-mono border border-slate-200">
                  ✓ Matching KB Pattern: Verified resolution guidelines for {result.intent}.
                </div>
              </div>
            </div>
          </div>

          {/* Stage 3: Escalation Decision Router */}
          <div className={`border rounded-xl p-5 shadow-sm transition ${
            result.escalate
              ? 'bg-amber-50/70 border-amber-300'
              : 'bg-emerald-50/70 border-emerald-300'
          }`}>
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                  result.escalate ? 'bg-amber-600 text-white' : 'bg-emerald-600 text-white'
                }`}>
                  3
                </div>
                <h3 className="text-sm font-bold text-slate-900">Stage 3: Escalation Decision Engine</h3>
              </div>
              <span className={`px-3 py-1 rounded-full text-xs font-bold font-mono flex items-center gap-1.5 ${
                result.escalate
                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                  : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
              }`}>
                {result.escalate ? (
                  <>
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-700" /> ESCALATE TO HUMAN AGENT
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" /> SAFE FOR AUTO-HANDLING
                  </>
                )}
              </span>
            </div>

            <div className="bg-white p-3.5 rounded-lg border border-slate-200 space-y-2 text-xs">
              <span className="text-slate-600 font-bold block">Decision Rationale & Safety Guardrails:</span>
              <p className="text-slate-800 font-sans leading-normal">
                {result.escalation_reason || "Message meets standard resolution criteria with no high-risk financial, security, or safety red flags."}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
