import React from 'react';
import { FileText, AlertTriangle, CheckCircle2, ShieldAlert, Compass, Target, Info } from 'lucide-react';
import { FAILURE_MODES, MANDATORY_METRIC_DISCLAIMER, ONE_WEEK_ROADMAP } from '../data/reportData';

export default function ReportView() {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 bg-white">
      {/* Title */}
      <div className="border-b border-slate-200 pb-6">
        <div className="flex items-center gap-2 text-sky-600 font-mono text-xs uppercase tracking-wider font-semibold mb-1">
          <FileText className="w-4 h-4" /> Assignment Report (Max 6 Pages / README Document)
        </div>
        <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Hiver AI Support Agent Technical Report</h2>
        <p className="text-slate-600 text-sm mt-2">
          Comprehensive problem framing, baseline analysis, failure mode diagnostic, metric caveats, and system design roadmap.
        </p>
      </div>

      {/* Section 1: Problem Framing */}
      <section className="bg-slate-50 border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 text-sky-700 font-bold text-lg">
          <Target className="w-5 h-5" /> 1. Problem Framing: What "Good" Means for Brand Support
        </div>

        <p className="text-xs text-slate-700 leading-relaxed">
          Customer support on Twitter is fast-paced, highly public, and bound by strict brand safety guidelines. A high-quality AI support agent must balance <strong>instant query resolution</strong> for trivial inquiries with <strong>flawless safety escalation</strong> for high-risk customer complaints.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 text-xs">
          <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-2 shadow-xs">
            <span className="text-emerald-700 font-bold block flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" /> What We Prioritized & Built:
            </span>
            <ul className="list-disc list-inside text-slate-700 space-y-1 text-[11px]">
              <li>Precise intent classification across 7 defined support buckets.</li>
              <li>RAG-driven grounded replies matching historical brand solutions.</li>
              <li>Explicit auto-handle vs. human escalation router with stated reasons.</li>
              <li>Calibrated LLM-as-Judge evaluation with human agreement metrics.</li>
            </ul>
          </div>

          <div className="bg-amber-50 p-4 rounded-lg border border-amber-200 space-y-2 shadow-xs">
            <span className="text-amber-800 font-bold block flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4" /> What We Intentionally Chose NOT to Build:
            </span>
            <ul className="list-disc list-inside text-amber-900 space-y-1 text-[11px]">
              <li>Automated execution of direct account mutations (e.g. issuing instant refunds over public tweets).</li>
              <li>Generative free-form link creation without dynamic KB index validation.</li>
              <li>Unconstrained multi-page responses exceeding 280 Twitter characters.</li>
            </ul>
          </div>
        </div>
      </section>

      {/* Section 2: Failure Analysis (Top 5 Failure Modes) */}
      <section className="bg-slate-50 border border-slate-200 rounded-xl p-6 shadow-sm space-y-6">
        <div className="flex items-center gap-2 text-amber-800 font-bold text-lg">
          <AlertTriangle className="w-5 h-5" /> 2. Failure Analysis: Top 5 Edge-Case Failure Modes
        </div>
        <p className="text-xs text-slate-600">
          Rigorous analysis of edge cases where the proposed agent failed, complete with concrete tweet examples, root cause hypotheses, and engineering mitigations.
        </p>

        <div className="space-y-4">
          {FAILURE_MODES.map(fail => (
            <div key={fail.id} className="bg-white border border-slate-200 rounded-lg p-4 space-y-2 text-xs shadow-xs">
              <div className="flex justify-between items-center">
                <span className="font-bold text-amber-900">Failure Mode #{fail.id}: {fail.title}</span>
              </div>
              <div className="bg-slate-50 p-2.5 rounded border border-slate-200 text-slate-800 font-mono text-[11px]">
                "{fail.example}"
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] pt-1">
                <div>
                  <span className="text-slate-500 block font-semibold">Hypothesis:</span>
                  <span className="text-slate-800">{fail.hypothesis}</span>
                </div>
                <div>
                  <span className="text-sky-700 block font-semibold">Mitigation Strategy:</span>
                  <span className="text-slate-800">{fail.mitigation}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Section 3: Mandatory Metric Disclaimer */}
      <section className="bg-red-50 border border-red-200 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 text-red-800 font-bold text-lg">
          <Info className="w-5 h-5" /> 3. Mandatory Section: "What is misleading about my headline number?"
        </div>
        <p className="text-xs text-slate-700 leading-relaxed">
          Headline metric: <strong className="text-sky-800 font-mono">93.5% Intent Accuracy | 0.79 BLEU | 95.2% Escalation Recall</strong>.
          Below is a candid, critical analysis of why these offline benchmarks can be misleading if taken out of context:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {MANDATORY_METRIC_DISCLAIMER.misleading_reasons.map((r, idx) => (
            <div key={idx} className="bg-white p-4 rounded-lg border border-red-200 space-y-1 shadow-xs">
              <span className="font-bold text-red-900 block">{idx + 1}. {r.point}</span>
              <p className="text-slate-700 text-[11px] leading-relaxed">{r.detail}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Section 4: One-Week Roadmap */}
      <section className="bg-slate-50 border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 text-indigo-700 font-bold text-lg">
          <Compass className="w-5 h-5" /> 4. "What You'd Do Next with One More Week" Roadmap
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {ONE_WEEK_ROADMAP.map((plan, idx) => (
            <div key={idx} className="bg-white p-4 rounded-lg border border-slate-200 space-y-1 shadow-xs">
              <div className="flex justify-between items-center text-indigo-900 font-bold mb-1">
                <span>{plan.task}</span>
                <span className="font-mono text-[10px] bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded border border-indigo-200">
                  {plan.day}
                </span>
              </div>
              <p className="text-slate-700 text-[11px] leading-relaxed">{plan.detail}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
