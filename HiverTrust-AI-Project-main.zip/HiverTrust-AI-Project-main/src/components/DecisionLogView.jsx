import React from 'react';
import { ListOrdered } from 'lucide-react';
import { DECISION_LOG } from '../data/reportData';

export default function DecisionLogView() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6 bg-white">
      {/* Title */}
      <div>
        <div className="flex items-center gap-2 text-sky-600 font-mono text-xs uppercase tracking-wider font-semibold mb-1">
          <ListOrdered className="w-4 h-4" /> Engineering Decisions Log
        </div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">14 Non-Obvious Architecture & System Decisions</h2>
        <p className="text-slate-600 text-sm mt-1">
          A plain list of key non-obvious engineering trade-offs, context, alternatives considered, and measured system impact.
        </p>
      </div>

      {/* Decision Log Table / Cards */}
      <div className="space-y-4">
        {DECISION_LOG.map(d => (
          <div key={d.id} className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-3">
                <span className="w-7 h-7 rounded-lg bg-sky-600 text-white font-mono font-bold text-xs flex items-center justify-center">
                  #{d.id}
                </span>
                <h3 className="text-sm font-bold text-slate-900">{d.decision}</h3>
              </div>
              <span className="bg-emerald-100 text-emerald-900 border border-emerald-300 px-2.5 py-1 rounded text-xs font-mono font-semibold">
                Impact: {d.impact}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
                <span className="text-slate-500 uppercase font-mono text-[10px] block mb-1">Context & Problem:</span>
                <p className="text-slate-700">{d.context}</p>
              </div>

              <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
                <span className="text-amber-800 uppercase font-mono text-[10px] block mb-1">Alternative Considered:</span>
                <p className="text-slate-700">{d.alternative}</p>
              </div>

              <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-xs">
                <span className="text-sky-800 uppercase font-mono text-[10px] block mb-1">Rationale & Choice:</span>
                <p className="text-slate-900 font-semibold">{d.rationale}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
