import React from 'react';
import { BarChart3, Award, Cpu } from 'lucide-react';
import { COMPUTED_METRICS } from '../data/goldenDataset';

export default function EvaluationHarnessView() {
  const models = [
    COMPUTED_METRICS.baseline1,
    COMPUTED_METRICS.baseline2,
    COMPUTED_METRICS.hiverTrustAgent
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 bg-white">
      {/* Title Header */}
      <div>
        <div className="flex items-center gap-2 text-indigo-600 font-mono text-xs uppercase tracking-wider font-semibold mb-1">
          <BarChart3 className="w-4 h-4" /> Benchmark Suite
        </div>
        <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Evaluation Harness & Baseline Comparisons</h2>
        <p className="text-slate-600 text-sm mt-1">
          Automated evaluation metrics (Intent Accuracy, BLEU, ROUGE-L, Grounding Faithfulness) and LLM-as-Judge rubric agreement vs. 200 hand-labelled human dataset examples.
        </p>
      </div>

      {/* Key Metrics Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs text-slate-500 font-medium block mb-1">Proposed Intent Accuracy</span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-sky-700">93.5%</span>
            <span className="text-xs text-emerald-700 font-semibold">+51.0% vs B1</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-2 block">Across 7 Defined Intent Buckets</span>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs text-slate-500 font-medium block mb-1">Reply BLEU Score</span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-indigo-700">0.79</span>
            <span className="text-xs text-emerald-700 font-semibold">+0.35 vs B2</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-2 block">Grounded vs Historical Resolutions</span>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs text-slate-500 font-medium block mb-1">Escalation Recall</span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-emerald-700">95.2%</span>
            <span className="text-xs text-emerald-700 font-semibold">+21.1% vs B2</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-2 block">High-Risk Safety Catch Rate</span>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 shadow-xs">
          <span className="text-xs text-slate-500 font-medium block mb-1">Judge Human Agreement (κ)</span>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-amber-700">0.88</span>
            <span className="text-xs text-emerald-700 font-semibold">Strong Agreement</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-2 block">Cohen's Kappa (50 dual-labelled)</span>
        </div>
      </div>

      {/* Main Comparative Benchmark Table */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 shadow-sm">
        <h3 className="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Award className="w-5 h-5 text-sky-600" /> Model Performance Comparison Matrix
        </h3>

        <div className="overflow-x-auto bg-white rounded-lg border border-slate-200">
          <table className="w-full text-left text-xs text-slate-800">
            <thead className="bg-slate-100 text-slate-600 uppercase font-mono border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Model Pipeline</th>
                <th className="py-3 px-4 text-center">Intent Acc.</th>
                <th className="py-3 px-4 text-center">BLEU</th>
                <th className="py-3 px-4 text-center">ROUGE-L</th>
                <th className="py-3 px-4 text-center">Faithfulness</th>
                <th className="py-3 px-4 text-center">Escalation Rec.</th>
                <th className="py-3 px-4 text-center">Judge Kappa (κ)</th>
                <th className="py-3 px-4 text-center">Avg Latency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {models.map((model, idx) => {
                const isProposed = idx === 2;
                return (
                  <tr key={idx} className={isProposed ? 'bg-sky-50/80 font-semibold' : 'hover:bg-slate-50'}>
                    <td className="py-4 px-4 flex items-center gap-2 font-bold text-slate-900">
                      {isProposed ? (
                        <span className="bg-sky-600 text-white px-2 py-0.5 rounded text-[11px] font-mono">
                          PROPOSED
                        </span>
                      ) : (
                        <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded text-[11px] font-mono">
                          BASELINE {idx + 1}
                        </span>
                      )}
                      {model.name}
                    </td>
                    <td className="py-4 px-4 text-center font-mono text-sky-800 font-bold">{model.intent_accuracy}</td>
                    <td className="py-4 px-4 text-center font-mono text-indigo-800">{model.reply_bleu}</td>
                    <td className="py-4 px-4 text-center font-mono text-indigo-800">{model.reply_rouge_l}</td>
                    <td className="py-4 px-4 text-center font-mono text-slate-800">{(model.grounding_faithfulness * 100).toFixed(0)}%</td>
                    <td className="py-4 px-4 text-center font-mono text-emerald-700 font-bold">{model.escalation_recall}</td>
                    <td className="py-4 px-4 text-center font-mono text-amber-800">{model.judge_human_kappa}</td>
                    <td className="py-4 px-4 text-center font-mono text-slate-600">{model.latency_ms}ms</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* LLM-as-Judge Evaluation Rubric Breakdown */}
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 shadow-sm">
        <h3 className="text-base font-bold text-slate-900 mb-3 flex items-center gap-2">
          <Cpu className="w-5 h-5 text-indigo-600" /> LLM-as-Judge Evaluation Rubric (1–5 Scale)
        </h3>
        <p className="text-xs text-slate-600 mb-6">
          Evaluates generated replies across 3 distinct axes using a calibrated LLM-as-Judge prompt.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
          <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-2 shadow-xs">
            <div className="flex justify-between items-center text-sky-800 font-bold">
              <span>1. Grounding Faithfulness</span>
              <span className="font-mono text-sm">4.8 / 5.0</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Measures whether drafted troubleshooting steps strictly match historical brand resolutions without inventing non-existent URLs or policy rules.
            </p>
          </div>

          <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-2 shadow-xs">
            <div className="flex justify-between items-center text-indigo-800 font-bold">
              <span>2. Actionable Helpfulness</span>
              <span className="font-mono text-sm">4.9 / 5.0</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Assesses whether the response gives concrete self-serve steps or safe DM routing rather than vague deflection.
            </p>
          </div>

          <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-2 shadow-xs">
            <div className="flex justify-between items-center text-emerald-800 font-bold">
              <span>3. Brand Tone Alignment</span>
              <span className="font-mono text-sm">4.9 / 5.0</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Evaluates empathy, concise length (&lt;280 chars), and brand-specific polite customer service standards.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
