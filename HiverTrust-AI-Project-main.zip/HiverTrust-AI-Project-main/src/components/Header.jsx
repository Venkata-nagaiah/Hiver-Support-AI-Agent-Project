import React from 'react';
import { Bot, BarChart3, Database, FileText, ListOrdered, User, Workflow, Sparkles, CheckCircle2 } from 'lucide-react';
import { DEVELOPER_DETAILS } from '../data/goldenDataset';

export default function Header({ activeTab, setActiveTab, onOpenDevModal }) {
  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
      {/* Top Banner: Developer Info */}
      <div className="bg-slate-900 text-slate-100 text-xs px-4 py-2 flex flex-wrap justify-between items-center border-b border-slate-800">
        <div className="flex items-center gap-3">
          <span className="bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded font-semibold border border-sky-400/30 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-sky-400" /> Hiver SDE Intern Take-Home Project
          </span>
          <span className="hidden sm:inline text-slate-500">|</span>
          <span className="font-medium text-slate-200">
            Developer: <strong className="text-white">{DEVELOPER_DETAILS.name}</strong> ({DEVELOPER_DETAILS.location})
          </span>
        </div>

        <div className="flex items-center gap-4 text-slate-300">
          <span className="hidden md:inline">📞 {DEVELOPER_DETAILS.phone}</span>
          <span className="hidden md:inline">✉️ {DEVELOPER_DETAILS.email}</span>
          <button
            onClick={onOpenDevModal}
            className="bg-sky-600 hover:bg-sky-500 text-white px-2.5 py-1 rounded text-xs font-medium transition flex items-center gap-1 shadow-sm"
          >
            <User className="w-3 h-3" /> Developer Details
          </button>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-md">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-slate-900 tracking-tight">HiverTrust AI</h1>
                <span className="text-[10px] bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded border border-emerald-300 font-mono font-medium flex items-center gap-1">
                  <CheckCircle2 className="w-2.5 h-2.5" /> Pipeline Live
                </span>
              </div>
              <p className="text-xs text-slate-500">AI Support Agent & Evaluation Suite for Twitter Support</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden lg:flex space-x-1">
            {[
              { id: 'simulator', label: 'Agent Simulator', icon: Bot },
              { id: 'diagrams', label: 'Physical Diagrams', icon: Workflow },
              { id: 'eval', label: 'Evaluation Harness', icon: BarChart3 },
              { id: 'golden', label: 'Golden Set (N=200)', icon: Database },
              { id: 'report', label: 'Assignment Report', icon: FileText },
              { id: 'decisions', label: 'Decision Log', icon: ListOrdered },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition flex items-center gap-2 ${
                    isActive
                      ? 'bg-sky-50 text-sky-700 border border-sky-200 font-semibold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-sky-600' : 'text-slate-500'}`} />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Mobile Nav Tabs */}
        <div className="lg:hidden flex overflow-x-auto py-2 gap-2 border-t border-slate-200 no-scrollbar">
          {[
            { id: 'simulator', label: 'Simulator', icon: Bot },
            { id: 'diagrams', label: 'Diagrams', icon: Workflow },
            { id: 'eval', label: 'Eval Harness', icon: BarChart3 },
            { id: 'golden', label: 'Golden Set', icon: Database },
            { id: 'report', label: 'Report', icon: FileText },
            { id: 'decisions', label: 'Decisions', icon: ListOrdered },
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-sky-50 text-sky-700 border border-sky-200 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 bg-slate-100'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}
