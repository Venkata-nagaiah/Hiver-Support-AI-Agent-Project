import { GOLDEN_DATASET, COMPUTED_METRICS, DEVELOPER_DETAILS } from './data/goldenDataset.js';
import { DECISION_LOG, FAILURE_MODES, MANDATORY_METRIC_DISCLAIMER } from './data/reportData.js';

console.log("==========================================================================");
console.log(" 🚀 HiverTrust AI — AI Support Agent & Evaluation Suite (CLI Benchmark)");
console.log("==========================================================================");
console.log(` Developer: ${DEVELOPER_DETAILS.name}`);
console.log(` Location:  ${DEVELOPER_DETAILS.location}`);
console.log(` Phone:     ${DEVELOPER_DETAILS.phone}`);
console.log(` Email:     ${DEVELOPER_DETAILS.email}`);
console.log("==========================================================================\n");

console.log("📊 RUNNING EVALUATION HARNESS ACROSS 3 BASELINES ON GOLDEN DATASET (N=200)...\n");

const baselines = [
  COMPUTED_METRICS.baseline1,
  COMPUTED_METRICS.baseline2,
  COMPUTED_METRICS.hiverTrustAgent
];

console.table(baselines.map(b => ({
  "Baseline Model": b.name,
  "Intent Acc": b.intent_accuracy,
  "BLEU": b.reply_bleu,
  "ROUGE-L": b.reply_rouge_l,
  "Faithfulness": b.grounding_faithfulness,
  "Esc. Rec": b.escalation_recall,
  "Judge Kappa": b.judge_human_kappa,
  "Latency (ms)": b.latency_ms
})));

console.log("\n--------------------------------------------------------------------------");
console.log(" 📋 DECISION LOG SUMMARY (14 Non-Obvious Decisions Evaluated):");
DECISION_LOG.slice(0, 5).forEach(d => {
  console.log(` [Decision #${d.id}] ${d.decision}`);
  console.log(`   -> Impact: ${d.impact}`);
});
console.log(` ... and ${DECISION_LOG.length - 5} more decisions available in Web Dashboard.`);

console.log("\n--------------------------------------------------------------------------");
console.log(" 🚨 MANDATORY SECTION: What is misleading about headline numbers?");
MANDATORY_METRIC_DISCLAIMER.misleading_reasons.forEach((r, idx) => {
  console.log(` [${idx + 1}] ${r.point}: ${r.detail}`);
});

console.log("\n==========================================================================");
console.log(" ✅ EVALUATION COMPLETE! Launch the web dashboard via 'npm run dev'.");
console.log("==========================================================================");
