import React, { useState } from 'react';
import Header from './components/Header';
import AgentSimulator from './components/AgentSimulator';
import DiagramsView from './components/DiagramsView';
import EvaluationHarnessView from './components/EvaluationHarnessView';
import GoldenDatasetExplorer from './components/GoldenDatasetExplorer';
import ReportView from './components/ReportView';
import DecisionLogView from './components/DecisionLogView';
import DeveloperModal from './components/DeveloperModal';
import { DEVELOPER_DETAILS } from './data/goldenDataset';

export default function App() {
  const [activeTab, setActiveTab] = useState('simulator');
  const [isDevModalOpen, setIsDevModalOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans">
      {/* Header with Developer Details Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenDevModal={() => setIsDevModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 pb-16 bg-white">
        {activeTab === 'simulator' && <AgentSimulator />}
        {activeTab === 'diagrams' && <DiagramsView />}
        {activeTab === 'eval' && <EvaluationHarnessView />}
        {activeTab === 'golden' && <GoldenDatasetExplorer />}
        {activeTab === 'report' && <ReportView />}
        {activeTab === 'decisions' && <DecisionLogView />}
      </main>

      {/* Developer Profile Modal */}
      <DeveloperModal
        isOpen={isDevModalOpen}
        onClose={() => setIsDevModalOpen(false)}
      />

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-6 text-xs text-slate-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <span className="text-white font-bold">HiverTrust AI Platform</span> — SDE Intern Take-Home Submission
          </div>

          <div className="flex items-center gap-4 text-slate-200">
            <span>Developer: <strong className="text-white">{DEVELOPER_DETAILS.name}</strong></span>
            <span>📍 {DEVELOPER_DETAILS.location}</span>
            <span>📞 {DEVELOPER_DETAILS.phone}</span>
            <span>✉️ {DEVELOPER_DETAILS.email}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
